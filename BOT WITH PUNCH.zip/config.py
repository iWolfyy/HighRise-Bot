# config.py

# Your Highrise bot's user ID
BOT_ID = "3cb267b31fd5f6479eadf5147d865ada9172d69dc7e8e84002f5c56eda7c363c"

# Your Highrise room ID
ROOM_ID = "688dc95dfc9e529b9004d23f"

# BOT ID
BOT_UID = "68ae3192bebc9d58c06f2b5d"

BOT_START_POSITION = {
    "x": 16.5,
    "y": 10.75,
    "z": 11.5,
    "facing": "FrontLeft"
}

# VIP tipping threshold (gold amount required for VIP status)
VIP_THRESHOLD = 40

NEWS_API_KEY = "3d7811bae0fc48c3b4a305e3b4249a9c"

HF_API_KEY = "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"

WEBHOOK_URL = "https://discord.com/api/webhooks/1398715083760210092/leub_4-iviz7DmPC2eBetbw3iUt5u0L5SCzF2Qsg4VvKd6tHLNoUTK7WHjLCAetu9Irg"

quickteleport = False